export type UserRole = 'student' | 'warden' | 'staff';

export type ComplaintCategory =
  | 'electrical'
  | 'plumbing'
  | 'sanitation'
  | 'furniture'
  | 'internet'
  | 'structural'
  | 'other';

export type ComplaintPriority = 'low' | 'medium' | 'high' | 'critical';

export type ComplaintStatus =
  | 'submitted'
  | 'under_review'
  | 'assigned'
  | 'in_progress'
  | 'resolved'
  | 'reopened';

export interface User {
  user_id: string;
  full_name: string;
  email: string;
  password_hash: string;
  role: UserRole;
  hostel_block: string;
  room_number: string;
  phone: string;
  specialty?: string; // For staff (e.g., Electrical, Plumbing, etc.)
  avatar?: string;
  created_at: string;
}

export interface ComplaintUpdate {
  update_id: string;
  complaint_id: string;
  updated_by_id: string;
  updated_by_name: string;
  updated_by_role: UserRole;
  previous_status: ComplaintStatus;
  new_status: ComplaintStatus;
  remarks: string;
  timestamp: string;
}

export interface Feedback {
  feedback_id: string;
  complaint_id: string;
  student_id: string;
  student_name: string;
  rating: number; // 1 to 5
  comments: string;
  created_at: string;
}

export interface Complaint {
  complaint_id: string; // e.g. CMP-2026-001
  student_id: string;
  student_name: string;
  student_email: string;
  student_phone?: string;
  title: string;
  description: string;
  category: ComplaintCategory;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  hostel_block: string;
  room_number: string;
  image_path?: string;
  resolution_image_path?: string;
  assigned_staff_id?: string;
  assigned_staff_name?: string;
  assigned_staff_specialty?: string;
  resolution_notes?: string;
  created_at: string;
  updated_at: string;
  resolved_at?: string;
}

export interface NotificationItem {
  notification_id: string;
  user_id: string;
  title: string;
  message: string;
  complaint_id?: string;
  is_read: boolean;
  created_at: string;
  type: 'status_update' | 'assignment' | 'resolved' | 'reopened' | 'feedback' | 'system';
}

export interface FilterOptions {
  searchQuery: string;
  category: string;
  status: string;
  priority: string;
  block: string;
  staffId: string;
}
