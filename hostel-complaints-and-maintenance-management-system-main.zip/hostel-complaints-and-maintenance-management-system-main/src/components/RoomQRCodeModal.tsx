import React, { useRef } from 'react';
import { useApp } from '../context/AppContext';
import { X, Printer, ArrowRight, ShieldCheck } from 'lucide-react';

export const RoomQRCodeModal: React.FC = () => {
  const { selectedRoomQR, closeRoomQR, setActiveTab } = useApp();
  const printRef = useRef<HTMLDivElement>(null);

  if (!selectedRoomQR) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleOpenComplaintForRoom = () => {
    closeRoomQR();
    setActiveTab('submit');
  };

  // Generate deterministic SVG QR code pattern based on room
  const seedString = `${selectedRoomQR.block}-${selectedRoomQR.room}`;
  const grid = 15;
  const cells: boolean[][] = [];
  for (let r = 0; r < grid; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < grid; c++) {
      // Corners finder markers
      const isTopLeftFinder = r < 4 && c < 4;
      const isTopRightFinder = r < 4 && c >= grid - 4;
      const isBottomLeftFinder = r >= grid - 4 && c < 4;
      if (isTopLeftFinder || isTopRightFinder || isBottomLeftFinder) {
        const inOuter =
          (r === 0 || r === 3 || c === 0 || c === 3) ||
          (r === 0 || r === 3 || c === grid - 4 || c === grid - 1) ||
          (r === grid - 4 || r === grid - 1 || c === 0 || c === 3);
        const inCenter =
          (r === 1 && c === 1) ||
          (r === 1 && c === grid - 2) ||
          (r === grid - 2 && c === 1);
        row.push(inOuter || inCenter);
      } else {
        const hash = (seedString.charCodeAt((r * grid + c) % seedString.length) * 31 + r * 17 + c * 23) % 10;
        row.push(hash > 4);
      }
    }
    cells.push(row);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">Room Maintenance Tag</h3>
            <p className="text-xs text-slate-500">Scan or print door tag for instant reporting</p>
          </div>
          <button
            onClick={closeRoomQR}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Card Area */}
        <div ref={printRef} className="p-6 text-center">
          <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 bg-slate-50/50">
            <div className="text-[11px] font-bold text-blue-600 uppercase tracking-wider mb-1">
              Hostel Care · Rapid Service Tag
            </div>
            <div className="text-xl font-extrabold text-slate-900 mb-0.5">
              Room {selectedRoomQR.room}
            </div>
            <div className="text-xs text-slate-500 mb-5">
              {selectedRoomQR.block}
            </div>

            {/* Simulated QR Code SVG */}
            <div className="inline-block p-3 bg-white rounded-xl shadow-xs border border-slate-200 mb-4">
              <svg width="160" height="160" viewBox={`0 0 ${grid} ${grid}`} className="shape-rendering-crispEdges">
                {cells.map((row, r) =>
                  row.map((active, c) => (
                    <rect
                      key={`${r}-${c}`}
                      x={c}
                      y={r}
                      width="1"
                      height="1"
                      fill={active ? '#0f172a' : '#ffffff'}
                    />
                  ))
                )}
              </svg>
            </div>

            <p className="text-xs text-slate-600 max-w-xs mx-auto mb-2">
              Scan with camera to file an instant maintenance ticket directly for this room.
            </p>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-emerald-700 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Campus Facility Management Certified</span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-white gap-3">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Door Placard</span>
          </button>

          <button
            onClick={handleOpenComplaintForRoom}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
          >
            <span>File Complaint For Room</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
