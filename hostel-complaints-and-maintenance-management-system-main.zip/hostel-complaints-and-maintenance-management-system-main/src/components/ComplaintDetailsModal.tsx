import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { CategoryIcon, getCategoryLabel } from './CategoryIcon';
import {
  X,
  Calendar,
  MapPin,
  User,
  Wrench,
  CheckCircle,
  AlertCircle,
  MessageSquare,
  Clock,
  Send,
  Star,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';
import { ComplaintStatus } from '../types';

export const ComplaintDetailsModal: React.FC = () => {
  const {
    selectedComplaintId,
    closeComplaintDetails,
    complaints,
    updates,
    feedbacks,
    users,
    currentUser,
    updateComplaintStatus,
    assignComplaint,
    reopenComplaint,
    submitFeedback,
  } = useApp();

  // Local state for actions
  const [selectedStaffId, setSelectedStaffId] = useState('');
  const [assignRemarks, setAssignRemarks] = useState('');
  const [statusToUpdate, setStatusToUpdate] = useState<ComplaintStatus>('in_progress');
  const [statusRemarks, setStatusRemarks] = useState('');
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [resolutionPhoto, setResolutionPhoto] = useState('');

  // Student feedback state
  const [rating, setRating] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  // Student reopen state
  const [reopenReason, setReopenReason] = useState('');
  const [showReopenBox, setShowReopenBox] = useState(false);

  if (!selectedComplaintId) return null;

  const complaint = complaints.find((c) => c.complaint_id === selectedComplaintId);
  if (!complaint) return null;

  const complaintUpdates = updates
    .filter((u) => u.complaint_id === complaint.complaint_id)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const existingFeedback = feedbacks.find((f) => f.complaint_id === complaint.complaint_id);
  const staffUsers = users.filter((u) => u.role === 'staff');

  const isStudent = currentUser?.role === 'student' || currentUser?.user_id === complaint.student_id;
  const isWarden = currentUser?.role === 'warden';
  const isAssignedStaff =
    currentUser?.role === 'staff' &&
    (!complaint.assigned_staff_id || complaint.assigned_staff_id === currentUser?.user_id);

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaffId) return;
    assignComplaint(complaint.complaint_id, selectedStaffId, assignRemarks);
    setAssignRemarks('');
    setSelectedStaffId('');
  };

  const handleStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    updateComplaintStatus(
      complaint.complaint_id,
      statusToUpdate,
      statusRemarks,
      resolutionNotes,
      resolutionPhoto
    );
    setStatusRemarks('');
    setResolutionNotes('');
    setResolutionPhoto('');
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackComment.trim()) return;
    submitFeedback(complaint.complaint_id, rating, feedbackComment);
    setFeedbackSubmitted(true);
  };

  const handleReopenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reopenReason.trim()) return;
    reopenComplaint(complaint.complaint_id, reopenReason);
    setShowReopenBox(false);
    setReopenReason('');
  };

  const steps = [
    { key: 'submitted', label: 'Submitted' },
    { key: 'under_review', label: 'Under Review' },
    { key: 'assigned', label: 'Assigned' },
    { key: 'in_progress', label: 'In Progress' },
    { key: 'resolved', label: 'Resolved' },
  ];

  const getStepState = (stepKey: string) => {
    if (complaint.status === 'reopened') {
      if (stepKey === 'submitted' || stepKey === 'under_review' || stepKey === 'assigned') return 'completed';
      return 'active';
    }

    const order = ['submitted', 'under_review', 'assigned', 'in_progress', 'resolved'];
    const currentIndex = order.indexOf(complaint.status);
    const stepIndex = order.indexOf(stepKey);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'pending';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-200 bg-slate-50/70">
          <div>
            <div className="flex items-center gap-3 mb-1.5 flex-wrap">
              <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                {complaint.complaint_id}
              </span>
              <StatusBadge status={complaint.status} />
              <PriorityBadge priority={complaint.priority} />
            </div>
            <h2 className="text-xl font-bold text-slate-900 leading-snug">
              {complaint.title}
            </h2>
          </div>
          <button
            onClick={closeComplaintDetails}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm text-slate-700">
          {/* Status Stepper */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Resolution Progress Tracker
            </div>
            <div className="grid grid-cols-5 gap-2 relative">
              {steps.map((step) => {
                const state = getStepState(step.key);
                return (
                  <div key={step.key} className="flex flex-col items-center text-center">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1.5 transition-colors ${
                        state === 'completed'
                          ? 'bg-emerald-600 text-white'
                          : state === 'active'
                          ? 'bg-blue-600 text-white ring-4 ring-blue-100'
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      {state === 'completed' ? '✓' : ''}
                      {state === 'active' ? '•' : ''}
                      {state === 'pending' ? '' : ''}
                    </div>
                    <span
                      className={`text-[11px] font-medium leading-tight ${
                        state === 'active'
                          ? 'text-blue-700 font-bold'
                          : state === 'completed'
                          ? 'text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>
            {complaint.status === 'reopened' && (
              <div className="mt-3 p-2.5 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-xs text-rose-800">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>
                  <strong>Complaint Reopened by Student:</strong> Initial repair was marked unsatisfactory. Awaiting re-inspection.
                </span>
              </div>
            )}
          </div>

          {/* Room & Meta Information Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Location & Category
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="font-semibold text-slate-900">
                  {complaint.hostel_block} · Room {complaint.room_number}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CategoryIcon category={complaint.category} />
                <span>{getCategoryLabel(complaint.category)}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                <span>Lodged: {new Date(complaint.created_at).toLocaleString()}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Assigned Personnel
              </div>
              {complaint.assigned_staff_name ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-blue-600 shrink-0" />
                    <span className="font-semibold text-slate-900">
                      {complaint.assigned_staff_name}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 pl-6">
                    {complaint.assigned_staff_specialty || 'General Maintenance'}
                  </div>
                </div>
              ) : (
                <div className="text-xs text-amber-700 bg-amber-50 p-2.5 rounded-lg border border-amber-200 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Unassigned — Pending Warden Triage</span>
                </div>
              )}

              <div className="pt-1 text-xs text-slate-500">
                <span className="font-medium text-slate-700">Reported By:</span>{' '}
                {complaint.student_name} ({complaint.student_email})
              </div>
            </div>
          </div>

          {/* Description & Attached Media */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Issue Description
            </div>
            <p className="text-slate-800 leading-relaxed whitespace-pre-line">
              {complaint.description}
            </p>

            {complaint.image_path && (
              <div className="pt-2">
                <div className="text-xs font-medium text-slate-500 mb-1.5">Attached Photo:</div>
                <div className="rounded-lg overflow-hidden border border-slate-200 max-h-56 w-fit bg-slate-100">
                  <img
                    src={complaint.image_path}
                    alt="Problem attachment"
                    className="max-h-56 object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            )}

            {complaint.resolution_notes && (
              <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  Technician Resolution Remarks
                </div>
                <p className="text-xs text-emerald-900 whitespace-pre-line">
                  {complaint.resolution_notes}
                </p>
                {complaint.resolution_image_path && (
                  <div className="mt-2">
                    <img
                      src={complaint.resolution_image_path}
                      alt="Resolution proof"
                      className="max-h-40 rounded border border-emerald-300"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Blocks: Dependent on Role */}

          {/* 1. Warden Assignment Form */}
          {isWarden && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 space-y-3">
              <div className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-4 h-4 text-blue-600" />
                Warden Action: Assign or Reassign Maintenance Technician
              </div>
              <form onSubmit={handleAssign} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Select Staff
                  </label>
                  <select
                    value={selectedStaffId}
                    onChange={(e) => setSelectedStaffId(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-blue-600"
                    required
                  >
                    <option value="">-- Choose Technician --</option>
                    {staffUsers.map((s) => (
                      <option key={s.user_id} value={s.user_id}>
                        {s.full_name} ({s.specialty || 'General'})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2 flex gap-2 items-end">
                  <div className="flex-1">
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Warden Remarks / Instructions
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Inspect before 4 PM today"
                      value={assignRemarks}
                      onChange={(e) => setAssignRemarks(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-blue-600"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap"
                  >
                    Assign Task
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* 2. Staff Status & Repair Notes Updater */}
          {(isAssignedStaff || isWarden) && complaint.status !== 'resolved' && (
            <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 space-y-3">
              <div className="text-xs font-bold text-indigo-900 uppercase tracking-wider flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-indigo-600" />
                Staff Work Progress & Resolution
              </div>
              <form onSubmit={handleStatusUpdate} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Update Status
                    </label>
                    <select
                      value={statusToUpdate}
                      onChange={(e) => setStatusToUpdate(e.target.value as ComplaintStatus)}
                      className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-indigo-600"
                    >
                      <option value="under_review">Under Review</option>
                      <option value="in_progress">In Progress (Work Underway)</option>
                      <option value="resolved">Resolved (Completed)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Progress Remarks
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Parts replaced, safety tested"
                      value={statusRemarks}
                      onChange={(e) => setStatusRemarks(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-indigo-600"
                      required
                    />
                  </div>
                </div>

                {statusToUpdate === 'resolved' && (
                  <div className="p-3 bg-white rounded-lg border border-indigo-200 space-y-2">
                    <label className="block text-xs font-semibold text-slate-800">
                      Final Resolution Notes for Student & Warden
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Detail the repair work done, parts replaced, and preventive recommendations..."
                      value={resolutionNotes}
                      onChange={(e) => setResolutionNotes(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 px-2.5 py-1.5 text-slate-900 focus:outline-indigo-600"
                      required
                    />
                  </div>
                )}

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
                  >
                    Update Progress
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* 3. Student Feedback or Reopen (when resolved) */}
          {complaint.status === 'resolved' && (
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/30 space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  Resolution Confirmation & Rating
                </div>
                {!showReopenBox && (
                  <button
                    onClick={() => setShowReopenBox(true)}
                    className="text-xs text-rose-600 hover:text-rose-700 font-medium underline"
                  >
                    Issue not fixed? Reopen complaint
                  </button>
                )}
              </div>

              {/* Existing Feedback View */}
              {existingFeedback ? (
                <div className="p-3 bg-white rounded-lg border border-emerald-200">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="flex text-amber-400">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-3.5 h-3.5 ${
                            star <= existingFeedback.rating ? 'fill-amber-400' : 'text-slate-200'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-slate-700">
                      {existingFeedback.rating} / 5 Stars
                    </span>
                    <span className="text-[11px] text-slate-400 ml-auto">
                      Submitted on {new Date(existingFeedback.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 italic">"{existingFeedback.comments}"</p>
                </div>
              ) : isStudent && !feedbackSubmitted ? (
                <form onSubmit={handleFeedbackSubmit} className="space-y-3 bg-white p-3 rounded-lg border border-slate-200">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Rate the maintenance service:
                    </label>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="p-1 hover:scale-110 transition-transform"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="text-xs text-slate-600 ml-2 font-medium">
                        {rating === 5 ? 'Excellent' : rating === 4 ? 'Good' : rating === 3 ? 'Average' : 'Poor'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Comments / Feedback
                    </label>
                    <input
                      type="text"
                      placeholder="How was the response time and repair quality?"
                      value={feedbackComment}
                      onChange={(e) => setFeedbackComment(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 px-2.5 py-2 text-slate-900 focus:outline-emerald-600"
                      required
                    />
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
                    >
                      Submit Rating
                    </button>
                  </div>
                </form>
              ) : null}

              {/* Reopen Box */}
              {showReopenBox && (
                <form onSubmit={handleReopenSubmit} className="p-3 bg-rose-50 rounded-lg border border-rose-200 space-y-2">
                  <div className="text-xs font-bold text-rose-900">
                    Why are you reopening this complaint?
                  </div>
                  <textarea
                    rows={2}
                    placeholder="Describe why the problem is still unresolved..."
                    value={reopenReason}
                    onChange={(e) => setReopenReason(e.target.value)}
                    className="w-full text-xs rounded-lg border border-rose-300 px-2.5 py-1.5 text-slate-900 focus:outline-rose-600"
                    required
                  />
                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReopenBox(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors"
                    >
                      Confirm Reopen
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Activity Timeline / Complaint Updates Table (PRD Section 10) */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Audit Trail & Status Updates ({complaintUpdates.length})
              </h4>
            </div>

            <div className="relative pl-5 border-l-2 border-slate-200 space-y-4">
              {complaintUpdates.map((up) => (
                <div key={up.update_id} className="relative">
                  {/* Timeline dot */}
                  <div className="absolute -left-[25px] top-1 w-3 h-3 rounded-full bg-slate-300 border-2 border-white ring-2 ring-slate-100" />
                  <div className="text-xs">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-900">{up.updated_by_name}</span>
                      <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded">
                        {up.updated_by_role}
                      </span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-500 text-[11px]">
                        {new Date(up.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <div className="mt-1 text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                      <div className="text-[11px] font-semibold text-blue-700 mb-0.5">
                        Transition: {up.previous_status} → {up.new_status}
                      </div>
                      <p className="text-slate-800">{up.remarks}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Complaint Reference: <span className="font-mono font-medium">{complaint.complaint_id}</span>
          </div>
          <button
            onClick={closeComplaintDetails}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
