import React from 'react';
import { ComplaintStatus, ComplaintPriority } from '../types';
import {
  Clock,
  Eye,
  UserCheck,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const StatusBadge: React.FC<{ status: ComplaintStatus; showIcon?: boolean }> = ({
  status,
  showIcon = true,
}) => {
  switch (status) {
    case 'submitted':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-slate-700 bg-slate-100 rounded border border-slate-200">
          {showIcon && <Clock className="w-3 h-3 text-slate-500" />}
          <span>Submitted</span>
        </span>
      );
    case 'under_review':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-amber-800 bg-amber-50 rounded border border-amber-200">
          {showIcon && <Eye className="w-3 h-3 text-amber-600" />}
          <span>Under Review</span>
        </span>
      );
    case 'assigned':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-blue-800 bg-blue-50 rounded border border-blue-200">
          {showIcon && <UserCheck className="w-3 h-3 text-blue-600" />}
          <span>Assigned</span>
        </span>
      );
    case 'in_progress':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-indigo-800 bg-indigo-50 rounded border border-indigo-200">
          {showIcon && <PlayCircle className="w-3 h-3 text-indigo-600" />}
          <span>In Progress</span>
        </span>
      );
    case 'resolved':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-emerald-800 bg-emerald-50 rounded border border-emerald-200">
          {showIcon && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
          <span>Resolved</span>
        </span>
      );
    case 'reopened':
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-rose-800 bg-rose-50 rounded border border-rose-200">
          {showIcon && <AlertTriangle className="w-3 h-3 text-rose-600" />}
          <span>Reopened</span>
        </span>
      );
    default:
      return <span className="text-xs text-slate-600">{status}</span>;
  }
};

export const PriorityBadge: React.FC<{ priority: ComplaintPriority }> = ({ priority }) => {
  switch (priority) {
    case 'critical':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold text-red-700 bg-red-50 rounded border border-red-200">
          <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
          Critical
        </span>
      );
    case 'high':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold text-orange-700 bg-orange-50 rounded border border-orange-200">
          <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
          High
        </span>
      );
    case 'medium':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-amber-700 bg-amber-50 rounded border border-amber-200">
          Medium
        </span>
      );
    case 'low':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-600 bg-slate-100 rounded border border-slate-200">
          Low
        </span>
      );
    default:
      return <span className="text-xs text-slate-600">{priority}</span>;
  }
};
