import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bell,
  Building2,
  LogOut,
  UserCheck,
  ChevronDown,
  QrCode,
  RotateCcw,
  PlusCircle,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentUser,
    activeTab,
    setActiveTab,
    logout,
    switchRole,
    users,
    unreadCount,
    resetToDefaults,
    openRoomQR,
  } = useApp();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab(currentUser ? (currentUser.role === 'warden' ? 'warden-dash' : currentUser.role === 'staff' ? 'staff-dash' : 'student-dash') : 'home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
                <Building2 className="w-5 h-5" />
              </div>
              <div className="leading-tight">
                <span className="block text-base font-bold text-slate-900 tracking-tight whitespace-nowrap">
                  HostelCare
                </span>
                <span className="text-[11px] text-slate-500 font-medium whitespace-nowrap">
                  Maintenance Portal
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: 4-5 Concise Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('home')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'home' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              Home
            </button>

            {currentUser?.role === 'student' && (
              <>
                <button
                  onClick={() => setActiveTab('student-dash')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'student-dash' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => setActiveTab('submit')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'submit' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Submit Complaint
                </button>
                <button
                  onClick={() => setActiveTab('my-complaints')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'my-complaints' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  My Complaints
                </button>
              </>
            )}

            {currentUser?.role === 'warden' && (
              <>
                <button
                  onClick={() => setActiveTab('warden-dash')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'warden-dash' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('manage-complaints')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'manage-complaints' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Manage Complaints
                </button>
                <button
                  onClick={() => setActiveTab('reports')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'reports' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Reports
                </button>
                <button
                  onClick={() => setActiveTab('feedback')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'feedback' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Feedback
                </button>
              </>
            )}

            {currentUser?.role === 'staff' && (
              <>
                <button
                  onClick={() => setActiveTab('staff-dash')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'staff-dash' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Work Orders
                </button>
                <button
                  onClick={() => setActiveTab('reports')}
                  className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'reports' ? 'text-blue-600 font-semibold' : ''
                  }`}
                >
                  Performance Log
                </button>
              </>
            )}

            <button
              onClick={() => setActiveTab('notifications')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 relative flex items-center gap-1.5 ${
                activeTab === 'notifications' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              <span>Notifications</span>
              {unreadCount > 0 && (
                <span className="font-mono text-[10px] font-bold text-white bg-blue-600 rounded-full px-1.5 py-0.2">
                  {unreadCount}
                </span>
              )}
            </button>
          </nav>

          {/* Zone 3: Primary Action / User Role Controls */}
          <div className="flex items-center gap-3 shrink-0">
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                  className="flex items-center gap-2.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
                >
                  <span className="w-2 h-2 rounded-full bg-blue-600" />
                  <span className="font-semibold text-slate-900">{currentUser.full_name}</span>
                  <span className="text-slate-500 uppercase tracking-wider text-[10px]">({currentUser.role})</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {roleMenuOpen && (
                  <div
                    className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-50 text-xs"
                    onClick={() => setRoleMenuOpen(false)}
                  >
                    <div className="px-3 py-2 border-b border-slate-100 text-slate-500">
                      <div className="font-semibold text-slate-900">{currentUser.full_name}</div>
                      <div className="text-[11px] truncate">{currentUser.email}</div>
                      <div className="text-[11px] text-blue-600 font-medium mt-0.5">
                        {currentUser.hostel_block} · {currentUser.room_number}
                      </div>
                    </div>

                    <div className="px-3 py-1 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      Switch Demo Role
                    </div>

                    <button
                      onClick={() => switchRole('student', 'USR-STU-001')}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center justify-between"
                    >
                      <span>Alex Sharma (Student B-304)</span>
                      {currentUser.user_id === 'USR-STU-001' && <span className="text-blue-600 font-bold">Active</span>}
                    </button>
                    <button
                      onClick={() => switchRole('warden', 'USR-WRD-001')}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center justify-between"
                    >
                      <span>Dr. Rajesh (Chief Warden)</span>
                      {currentUser.user_id === 'USR-WRD-001' && <span className="text-blue-600 font-bold">Active</span>}
                    </button>
                    <button
                      onClick={() => switchRole('staff', 'USR-STF-001')}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center justify-between"
                    >
                      <span>Ramesh (Electrician)</span>
                      {currentUser.user_id === 'USR-STF-001' && <span className="text-blue-600 font-bold">Active</span>}
                    </button>
                    <button
                      onClick={() => switchRole('staff', 'USR-STF-002')}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center justify-between"
                    >
                      <span>Suresh (Plumber)</span>
                      {currentUser.user_id === 'USR-STF-002' && <span className="text-blue-600 font-bold">Active</span>}
                    </button>

                    <div className="border-t border-slate-100 my-1" />

                    <button
                      onClick={() => {
                        if (currentUser.hostel_block && currentUser.room_number) {
                          openRoomQR(currentUser.hostel_block, currentUser.room_number);
                        } else {
                          openRoomQR('Block B (Bhaskara)', 'B-304');
                        }
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center gap-2 text-slate-700"
                    >
                      <QrCode className="w-3.5 h-3.5 text-slate-500" />
                      <span>Room Maintenance QR Code</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('profile')}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center gap-2 text-slate-700"
                    >
                      <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                      <span>User Profile</span>
                    </button>

                    <button
                      onClick={resetToDefaults}
                      className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center gap-2 text-slate-700"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                      <span>Reset Demo Data</span>
                    </button>

                    <div className="border-t border-slate-100 my-1" />

                    <button
                      onClick={logout}
                      className="w-full text-left px-3 py-1.5 hover:bg-red-50 text-red-600 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Log Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('login')}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-blue-600 transition-colors whitespace-nowrap shrink-0"
                >
                  Log In
                </button>
                <button
                  onClick={() => setActiveTab('register')}
                  className="px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap shrink-0"
                >
                  Register
                </button>
              </div>
            )}

            {currentUser?.role === 'student' && (
              <button
                onClick={() => setActiveTab('submit')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap shrink-0 shadow-xs"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>New Complaint</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
