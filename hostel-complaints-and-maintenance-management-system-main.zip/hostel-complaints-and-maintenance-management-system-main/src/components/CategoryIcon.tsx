import React from 'react';
import {
  Zap,
  Droplets,
  Sparkles,
  Armchair,
  Wifi,
  Wrench,
  HelpCircle,
} from 'lucide-react';
import { ComplaintCategory } from '../types';

export const CategoryIcon: React.FC<{ category: ComplaintCategory; className?: string }> = ({
  category,
  className = 'w-4 h-4',
}) => {
  switch (category) {
    case 'electrical':
      return <Zap className={`${className} text-amber-500`} />;
    case 'plumbing':
      return <Droplets className={`${className} text-blue-500`} />;
    case 'sanitation':
      return <Sparkles className={`${className} text-emerald-500`} />;
    case 'furniture':
      return <Armchair className={`${className} text-orange-500`} />;
    case 'internet':
      return <Wifi className={`${className} text-purple-500`} />;
    case 'structural':
      return <Wrench className={`${className} text-slate-600`} />;
    default:
      return <HelpCircle className={`${className} text-slate-400`} />;
  }
};

export const getCategoryLabel = (cat: ComplaintCategory): string => {
  switch (cat) {
    case 'electrical':
      return 'Electrical Issues';
    case 'plumbing':
      return 'Plumbing & Water';
    case 'sanitation':
      return 'Sanitation & Cleaning';
    case 'furniture':
      return 'Furniture Damage';
    case 'internet':
      return 'Wi-Fi & Internet';
    case 'structural':
      return 'Room & Structural';
    default:
      return 'Other Issues';
  }
};
