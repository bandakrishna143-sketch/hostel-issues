import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Complaint,
  ComplaintUpdate,
  Feedback,
  NotificationItem,
  UserRole,
  ComplaintStatus,
  ComplaintPriority,
  ComplaintCategory,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_COMPLAINTS,
  INITIAL_UPDATES,
  INITIAL_FEEDBACK,
  INITIAL_NOTIFICATIONS,
} from '../data/seedData';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  complaints: Complaint[];
  updates: ComplaintUpdate[];
  feedbacks: Feedback[];
  notifications: NotificationItem[];
  activeTab: string;
  selectedComplaintId: string | null;
  selectedRoomQR: { block: string; room: string } | null;
  unreadCount: number;

  setActiveTab: (tab: string) => void;
  setCurrentUser: (user: User | null) => void;
  openComplaintDetails: (id: string) => void;
  closeComplaintDetails: () => void;
  openRoomQR: (block: string, room: string) => void;
  closeRoomQR: () => void;

  login: (email: string, password: string) => { success: boolean; error?: string };
  registerStudent: (student: Omit<User, 'user_id' | 'role' | 'created_at' | 'password_hash'> & { password: string }) => { success: boolean; error?: string };
  logout: () => void;
  switchRole: (role: UserRole, specificUserId?: string) => void;

  createComplaint: (data: {
    title: string;
    description: string;
    category: ComplaintCategory;
    priority: ComplaintPriority;
    hostel_block: string;
    room_number: string;
    image_path?: string;
  }) => Complaint;

  updateComplaintStatus: (
    complaintId: string,
    newStatus: ComplaintStatus,
    remarks: string,
    resolutionNotes?: string,
    resolutionImage?: string
  ) => void;

  assignComplaint: (complaintId: string, staffId: string, remarks?: string) => void;
  reopenComplaint: (complaintId: string, reason: string) => void;
  submitFeedback: (complaintId: string, rating: number, comments: string) => void;

  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  resetToDefaults: () => void;
  exportDatabaseJSON: () => void;
  importDatabaseJSON: (jsonStr: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'hostel_system_v1_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from local storage or use seed data
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}users`);
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}current_user`);
      if (saved) return JSON.parse(saved);
      // Default to student Alex Sharma for immediate preview
      return INITIAL_USERS[0];
    } catch {
      return INITIAL_USERS[0];
    }
  });

  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}complaints`);
      return saved ? JSON.parse(saved) : INITIAL_COMPLAINTS;
    } catch {
      return INITIAL_COMPLAINTS;
    }
  });

  const [updates, setUpdates] = useState<ComplaintUpdate[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}updates`);
      return saved ? JSON.parse(saved) : INITIAL_UPDATES;
    } catch {
      return INITIAL_UPDATES;
    }
  });

  const [feedbacks, setFeedbacks] = useState<Feedback[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}feedbacks`);
      return saved ? JSON.parse(saved) : INITIAL_FEEDBACK;
    } catch {
      return INITIAL_FEEDBACK;
    }
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}notifications`);
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null);
  const [selectedRoomQR, setSelectedRoomQR] = useState<{ block: string; room: string } | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}users`, JSON.stringify(users));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}current_user`, JSON.stringify(currentUser));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}complaints`, JSON.stringify(complaints));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}updates`, JSON.stringify(updates));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}feedbacks`, JSON.stringify(feedbacks));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}notifications`, JSON.stringify(notifications));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }, [users, currentUser, complaints, updates, feedbacks, notifications]);

  // Derived unread notifications for current user
  const unreadCount = notifications.filter(
    (n) => (!currentUser || n.user_id === currentUser.user_id) && !n.is_read
  ).length;

  const openComplaintDetails = (id: string) => {
    setSelectedComplaintId(id);
  };

  const closeComplaintDetails = () => {
    setSelectedComplaintId(null);
  };

  const openRoomQR = (block: string, room: string) => {
    setSelectedRoomQR({ block, room });
  };

  const closeRoomQR = () => {
    setSelectedRoomQR(null);
  };

  const login = (email: string, password: string) => {
    const found = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!found) {
      return { success: false, error: 'No user registered with this email address.' };
    }
    if (found.password_hash !== password) {
      return { success: false, error: 'Incorrect password entered.' };
    }
    setCurrentUser(found);
    if (found.role === 'warden') {
      setActiveTab('warden-dash');
    } else if (found.role === 'staff') {
      setActiveTab('staff-dash');
    } else {
      setActiveTab('student-dash');
    }
    return { success: true };
  };

  const registerStudent = (data: Omit<User, 'user_id' | 'role' | 'created_at' | 'password_hash'> & { password: string }) => {
    const exists = users.some((u) => u.email.toLowerCase() === data.email.trim().toLowerCase());
    if (exists) {
      return { success: false, error: 'A user with this email already exists.' };
    }

    const newUser: User = {
      user_id: `USR-STU-${String(users.length + 1).padStart(3, '0')}`,
      full_name: data.full_name,
      email: data.email.trim().toLowerCase(),
      password_hash: data.password,
      role: 'student',
      hostel_block: data.hostel_block,
      room_number: data.room_number,
      phone: data.phone,
      created_at: new Date().toISOString(),
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    setActiveTab('student-dash');
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveTab('home');
  };

  const switchRole = (role: UserRole, specificUserId?: string) => {
    if (specificUserId) {
      const targetUser = users.find((u) => u.user_id === specificUserId);
      if (targetUser) {
        setCurrentUser(targetUser);
        if (targetUser.role === 'warden') setActiveTab('warden-dash');
        else if (targetUser.role === 'staff') setActiveTab('staff-dash');
        else setActiveTab('student-dash');
        return;
      }
    }

    // Default by role
    const matched = users.find((u) => u.role === role);
    if (matched) {
      setCurrentUser(matched);
      if (role === 'warden') setActiveTab('warden-dash');
      else if (role === 'staff') setActiveTab('staff-dash');
      else setActiveTab('student-dash');
    }
  };

  const createComplaint = (data: {
    title: string;
    description: string;
    category: ComplaintCategory;
    priority: ComplaintPriority;
    hostel_block: string;
    room_number: string;
    image_path?: string;
  }) => {
    const count = complaints.length + 1;
    const complaintId = `CMP-${new Date().getFullYear()}-${String(count).padStart(3, '0')}`;
    const now = new Date().toISOString();

    const studentId = currentUser ? currentUser.user_id : 'USR-STU-001';
    const studentName = currentUser ? currentUser.full_name : 'Guest Student';
    const studentEmail = currentUser ? currentUser.email : 'student@hostel.edu';
    const studentPhone = currentUser?.phone;

    const newComplaint: Complaint = {
      complaint_id: complaintId,
      student_id: studentId,
      student_name: studentName,
      student_email: studentEmail,
      student_phone: studentPhone,
      title: data.title,
      description: data.description,
      category: data.category,
      priority: data.priority,
      status: 'submitted',
      hostel_block: data.hostel_block,
      room_number: data.room_number,
      image_path: data.image_path,
      created_at: now,
      updated_at: now,
    };

    const initialUpdate: ComplaintUpdate = {
      update_id: `UPD-${String(updates.length + 1).padStart(3, '0')}`,
      complaint_id: complaintId,
      updated_by_id: studentId,
      updated_by_name: studentName,
      updated_by_role: 'student',
      previous_status: 'submitted',
      new_status: 'submitted',
      remarks: 'Complaint submitted by student.',
      timestamp: now,
    };

    // Notification for Warden
    const wardenUser = users.find((u) => u.role === 'warden');
    const newNotif: NotificationItem = {
      notification_id: `NOTIF-${String(notifications.length + 1).padStart(3, '0')}`,
      user_id: wardenUser ? wardenUser.user_id : 'USR-WRD-001',
      title: 'New Complaint Registered',
      message: `${studentName} lodged ${complaintId} in ${data.hostel_block} (${data.room_number}) [${data.priority.toUpperCase()} Priority].`,
      complaint_id: complaintId,
      is_read: false,
      created_at: now,
      type: 'status_update',
    };

    setComplaints((prev) => [newComplaint, ...prev]);
    setUpdates((prev) => [...prev, initialUpdate]);
    setNotifications((prev) => [newNotif, ...prev]);

    return newComplaint;
  };

  const updateComplaintStatus = (
    complaintId: string,
    newStatus: ComplaintStatus,
    remarks: string,
    resolutionNotes?: string,
    resolutionImage?: string
  ) => {
    const target = complaints.find((c) => c.complaint_id === complaintId);
    if (!target) return;

    const now = new Date().toISOString();
    const updaterId = currentUser ? currentUser.user_id : 'USR-WRD-001';
    const updaterName = currentUser ? currentUser.full_name : 'Administrator';
    const updaterRole = currentUser ? currentUser.role : 'warden';

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.complaint_id === complaintId) {
          return {
            ...c,
            status: newStatus,
            updated_at: now,
            resolved_at: newStatus === 'resolved' ? now : c.resolved_at,
            resolution_notes: resolutionNotes || c.resolution_notes,
            resolution_image_path: resolutionImage || c.resolution_image_path,
          };
        }
        return c;
      })
    );

    const newUpdate: ComplaintUpdate = {
      update_id: `UPD-${String(updates.length + 1).padStart(3, '0')}`,
      complaint_id: complaintId,
      updated_by_id: updaterId,
      updated_by_name: updaterName,
      updated_by_role: updaterRole,
      previous_status: target.status,
      new_status: newStatus,
      remarks: remarks || `Status changed to ${newStatus}`,
      timestamp: now,
    };
    setUpdates((prev) => [...prev, newUpdate]);

    // Send notification to student
    const notif: NotificationItem = {
      notification_id: `NOTIF-${String(notifications.length + 1).padStart(3, '0')}`,
      user_id: target.student_id,
      title: `Complaint Status: ${newStatus.replace('_', ' ').toUpperCase()}`,
      message: `Your complaint ${complaintId} is now ${newStatus.replace('_', ' ')}. Remarks: ${remarks || 'Updated by ' + updaterName}`,
      complaint_id: complaintId,
      is_read: false,
      created_at: now,
      type: newStatus === 'resolved' ? 'resolved' : 'status_update',
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const assignComplaint = (complaintId: string, staffId: string, remarks?: string) => {
    const staff = users.find((u) => u.user_id === staffId);
    if (!staff) return;

    const now = new Date().toISOString();
    const updaterId = currentUser ? currentUser.user_id : 'USR-WRD-001';
    const updaterName = currentUser ? currentUser.full_name : 'Dr. Rajesh Kumar';

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.complaint_id === complaintId) {
          return {
            ...c,
            assigned_staff_id: staff.user_id,
            assigned_staff_name: staff.full_name,
            assigned_staff_specialty: staff.specialty,
            status: c.status === 'submitted' || c.status === 'under_review' ? 'assigned' : c.status,
            updated_at: now,
          };
        }
        return c;
      })
    );

    const newUpdate: ComplaintUpdate = {
      update_id: `UPD-${String(updates.length + 1).padStart(3, '0')}`,
      complaint_id: complaintId,
      updated_by_id: updaterId,
      updated_by_name: updaterName,
      updated_by_role: 'warden',
      previous_status: 'submitted',
      new_status: 'assigned',
      remarks: remarks || `Assigned to ${staff.full_name} (${staff.specialty || 'Maintenance Specialist'}).`,
      timestamp: now,
    };
    setUpdates((prev) => [...prev, newUpdate]);

    // Notify staff
    const staffNotif: NotificationItem = {
      notification_id: `NOTIF-${String(notifications.length + 1).padStart(3, '0')}`,
      user_id: staff.user_id,
      title: 'New Work Order Assigned',
      message: `You were assigned ${complaintId}. Reason: ${remarks || 'Standard assignment'}`,
      complaint_id: complaintId,
      is_read: false,
      created_at: now,
      type: 'assignment',
    };

    // Notify student
    const targetComp = complaints.find((c) => c.complaint_id === complaintId);
    if (targetComp) {
      const studentNotif: NotificationItem = {
        notification_id: `NOTIF-${String(notifications.length + 2).padStart(3, '0')}`,
        user_id: targetComp.student_id,
        title: 'Technician Assigned',
        message: `${staff.full_name} has been assigned to work on your request (${complaintId}).`,
        complaint_id: complaintId,
        is_read: false,
        created_at: now,
        type: 'assignment',
      };
      setNotifications((prev) => [staffNotif, studentNotif, ...prev]);
    } else {
      setNotifications((prev) => [staffNotif, ...prev]);
    }
  };

  const reopenComplaint = (complaintId: string, reason: string) => {
    const target = complaints.find((c) => c.complaint_id === complaintId);
    if (!target) return;

    const now = new Date().toISOString();
    const updaterId = currentUser ? currentUser.user_id : target.student_id;
    const updaterName = currentUser ? currentUser.full_name : target.student_name;

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.complaint_id === complaintId) {
          return {
            ...c,
            status: 'reopened',
            updated_at: now,
          };
        }
        return c;
      })
    );

    const newUpdate: ComplaintUpdate = {
      update_id: `UPD-${String(updates.length + 1).padStart(3, '0')}`,
      complaint_id: complaintId,
      updated_by_id: updaterId,
      updated_by_name: updaterName,
      updated_by_role: 'student',
      previous_status: target.status,
      new_status: 'reopened',
      remarks: `Reopened by student: ${reason}`,
      timestamp: now,
    };
    setUpdates((prev) => [...prev, newUpdate]);

    // Alert Warden
    const warden = users.find((u) => u.role === 'warden');
    const notif: NotificationItem = {
      notification_id: `NOTIF-${String(notifications.length + 1).padStart(3, '0')}`,
      user_id: warden ? warden.user_id : 'USR-WRD-001',
      title: 'Complaint Reopened',
      message: `${target.student_name} reopened ${complaintId}. Reason: ${reason}`,
      complaint_id: complaintId,
      is_read: false,
      created_at: now,
      type: 'reopened',
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const submitFeedback = (complaintId: string, rating: number, comments: string) => {
    const now = new Date().toISOString();
    const studentId = currentUser ? currentUser.user_id : 'USR-STU-001';
    const studentName = currentUser ? currentUser.full_name : 'Student';

    const newFdb: Feedback = {
      feedback_id: `FDB-${String(feedbacks.length + 1).padStart(3, '0')}`,
      complaint_id: complaintId,
      student_id: studentId,
      student_name: studentName,
      rating,
      comments,
      created_at: now,
    };

    setFeedbacks((prev) => [newFdb, ...prev]);

    // Notify warden of feedback
    const warden = users.find((u) => u.role === 'warden');
    const notif: NotificationItem = {
      notification_id: `NOTIF-${String(notifications.length + 1).padStart(3, '0')}`,
      user_id: warden ? warden.user_id : 'USR-WRD-001',
      title: 'New Service Rating Submitted',
      message: `${studentName} left a ${rating}-star review for complaint ${complaintId}: "${comments.slice(0, 40)}..."`,
      complaint_id: complaintId,
      is_read: false,
      created_at: now,
      type: 'feedback',
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.notification_id === id ? { ...n, is_read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) =>
      prev.map((n) =>
        !currentUser || n.user_id === currentUser.user_id ? { ...n, is_read: true } : n
      )
    );
  };

  const resetToDefaults = () => {
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setComplaints(INITIAL_COMPLAINTS);
    setUpdates(INITIAL_UPDATES);
    setFeedbacks(INITIAL_FEEDBACK);
    setNotifications(INITIAL_NOTIFICATIONS);
    setActiveTab('home');
    setSelectedComplaintId(null);
    setSelectedRoomQR(null);
    localStorage.clear();
  };

  const exportDatabaseJSON = () => {
    const data = {
      version: '1.0',
      exported_at: new Date().toISOString(),
      users,
      complaints,
      updates,
      feedbacks,
      notifications,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hostel_maintenance_db_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importDatabaseJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.users && parsed.complaints) {
        setUsers(parsed.users);
        setComplaints(parsed.complaints);
        if (parsed.updates) setUpdates(parsed.updates);
        if (parsed.feedbacks) setFeedbacks(parsed.feedbacks);
        if (parsed.notifications) setNotifications(parsed.notifications);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        complaints,
        updates,
        feedbacks,
        notifications,
        activeTab,
        selectedComplaintId,
        selectedRoomQR,
        unreadCount,
        setActiveTab,
        setCurrentUser,
        openComplaintDetails,
        closeComplaintDetails,
        openRoomQR,
        closeRoomQR,
        login,
        registerStudent,
        logout,
        switchRole,
        createComplaint,
        updateComplaintStatus,
        assignComplaint,
        reopenComplaint,
        submitFeedback,
        markNotificationRead,
        markAllNotificationsRead,
        resetToDefaults,
        exportDatabaseJSON,
        importDatabaseJSON,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
};
