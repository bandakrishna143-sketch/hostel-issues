import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { ComplaintDetailsModal } from './components/ComplaintDetailsModal';
import { RoomQRCodeModal } from './components/RoomQRCodeModal';
import { HomePage } from './pages/HomePage';
import { StudentDashboard } from './pages/StudentDashboard';
import { SubmitComplaintPage } from './pages/SubmitComplaintPage';
import { MyComplaintsPage } from './pages/MyComplaintsPage';
import { WardenDashboard } from './pages/WardenDashboard';
import { ManageComplaintsPage } from './pages/ManageComplaintsPage';
import { StaffDashboard } from './pages/StaffDashboard';
import { NotificationsPage } from './pages/NotificationsPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { ReportsPage } from './pages/ReportsPage';
import { ProfilePage } from './pages/ProfilePage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { Building2, ShieldCheck, Heart } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, switchRole } = useApp();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage />;
      case 'student-dash':
        return <StudentDashboard />;
      case 'submit':
        return <SubmitComplaintPage />;
      case 'my-complaints':
        return <MyComplaintsPage />;
      case 'warden-dash':
        return <WardenDashboard />;
      case 'manage-complaints':
        return <ManageComplaintsPage />;
      case 'staff-dash':
        return <StaffDashboard />;
      case 'notifications':
        return <NotificationsPage />;
      case 'feedback':
        return <FeedbackPage />;
      case 'reports':
        return <ReportsPage />;
      case 'profile':
        return <ProfilePage />;
      case 'login':
        return <LoginPage />;
      case 'register':
        return <RegisterPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 antialiased">
      {/* Top Bar Contract Compliant Header */}
      <Navbar />

      {/* Main Container Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {renderActiveView()}
      </main>

      {/* Modals & Overlays */}
      <ComplaintDetailsModal />
      <RoomQRCodeModal />

      {/* Clean Global Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-600" />
            <span className="font-semibold text-slate-700">Hostel Maintenance & Complaint System</span>
            <span className="text-slate-300">·</span>
            <span>Residential Campus Facility Management</span>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            <button
              onClick={() => switchRole('student', 'USR-STU-001')}
              className="hover:text-blue-600 transition-colors"
            >
              Demo: Student Alex
            </button>
            <span className="text-slate-300">·</span>
            <button
              onClick={() => switchRole('warden', 'USR-WRD-001')}
              className="hover:text-blue-600 transition-colors"
            >
              Demo: Chief Warden
            </button>
            <span className="text-slate-300">·</span>
            <button
              onClick={() => switchRole('staff', 'USR-STF-001')}
              className="hover:text-blue-600 transition-colors"
            >
              Demo: Electrician Ramesh
            </button>
            <span className="text-slate-300">·</span>
            <button
              onClick={() => setActiveTab('reports')}
              className="hover:text-blue-600 transition-colors"
            >
              SLA Reports
            </button>
          </div>

          <div className="text-[11px] text-slate-400">
            Compliant with Campus Accommodation Standard SOP 2026
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
